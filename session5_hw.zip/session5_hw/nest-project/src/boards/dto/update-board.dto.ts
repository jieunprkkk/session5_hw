export class UpdateBoardDto {
    title?: string;
    content?: string;
  }