export class CreateBoardDto {
  title: string;
  content: string;
}