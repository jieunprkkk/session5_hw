export class CreateUserProfileDto {
    avatarUrl: string;
    bio: string;
  }