export class UpdateUserProfileDto {
    avatarUrl?: string;
    bio?: string;
  }